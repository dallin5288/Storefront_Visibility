# round2 > 2025-02-23 7:48am
https://universe.roboflow.com/growthfactor/round2-6eicc

Provided by a Roboflow user
License: CC BY 4.0

